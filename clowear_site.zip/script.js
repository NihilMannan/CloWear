function addToCart() {
  alert("Item added to cart!");
}